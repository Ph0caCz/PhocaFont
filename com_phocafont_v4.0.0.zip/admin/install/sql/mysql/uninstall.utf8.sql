DROP TABLE IF EXISTS `#__phocafont_font`;
