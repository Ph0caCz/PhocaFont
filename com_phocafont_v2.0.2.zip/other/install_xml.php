<?php
/*********** XML PARAMETERS AND VALUES ************/
$xml_item = "component";// component | template
$xml_file = "phocafont.xml";		
$xml_name = "com_phocafont";
$xml_creation_date = "07/12/2011";
$xml_author = "Jan Pavelka (www.phoca.cz)";
$xml_author_email = "";
$xml_author_url = "www.phoca.cz";
$xml_copyright = "Jan Pavelka";
$xml_license = "GNU/GPL";
$xml_version = "2.0.2";
$xml_description = "Phoca Font";
$xml_copy_file = 1;//Copy other files in to administration area (only for development), ./front, ./language, ./other

$xml_menu = array (0 => "COM_PHOCAFONT", 1 => "option=com_phocafont", 2 => "components/com_phocafont/assets/images/icon-16-pfont-menu.png", 3 => 'COM_PHOCAFONT', 4 => 'phocafontcp');
$xml_submenu[0] = array (0 => "COM_PHOCAFONT_CONTROLPANEL", 1 => "option=com_phocafont", 2 => "components/com_phocafont/assets/images/icon-16-pfont-cp.png", 3 => 'COM_PHOCAFONT_CONTROLPANEL', 4 => 'phocafontcp');
$xml_submenu[1] = array (0 => "COM_PHOCAFONT_FONTS", 1 => "option=com_phocafont&view=phocafontfonts", 2 => "components/com_phocafont/assets/images/icon-16-pfont-font.png", 3 => 'COM_PHOCAFONT_FONTS', 4 => 'phocafontfonts');
$xml_submenu[2] = array (0 => "COM_PHOCAFONT_INFO", 1 => "option=com_phocafont&view=phocafontinfo", 2 => "components/com_phocafont/assets/images/icon-16-pfont-info.png", 3 => 'COM_PHOCAFONT_INFO', 4 => 'phocafontinfo');

$xml_install_file = 'install.phocafont.php'; 
$xml_uninstall_file = 'uninstall.phocafont.php';
/*********** XML PARAMETERS AND VALUES ************/
?>