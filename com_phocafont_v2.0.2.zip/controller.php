<?php
/*
 * @package		Joomla.Framework
 * @copyright	Copyright (C) 2005 - 2010 Open Source Matters, Inc. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 *
 * @component Phoca Component
 * @copyright Copyright (C) Jan Pavelka www.phoca.cz
 * @license http://www.gnu.org/copyleft/gpl.html GNU General Public License version 2 or later;
 */
jimport('joomla.application.component.controller');

// Submenu view
$view	= JRequest::getVar( 'view', '', '', 'string', JREQUEST_ALLOWRAW );

$l['cp']	= JText::_('COM_PHOCAFONT_CONTROL_PANEL');
$l['cf']	= JText::_('COM_PHOCAFONT_FONTS');
$l['i']		= JText::_('COM_PHOCAFONT_INFO');

if ($view == '' || $view == 'phocafontcp') {
	JSubMenuHelper::addEntry($l['cp'], 'index.php?option=com_phocafont', true);
	JSubMenuHelper::addEntry($l['cf'], 'index.php?option=com_phocafont&view=phocafontfonts' );
	JSubMenuHelper::addEntry($l['i'], 'index.php?option=com_phocafont&view=phocafontinfo');
}

if ($view == 'phocafontfonts') {
	JSubMenuHelper::addEntry($l['cp'], 'index.php?option=com_phocafont');
	JSubMenuHelper::addEntry($l['cf'], 'index.php?option=com_phocafont&view=phocafontfonts', true );
	JSubMenuHelper::addEntry($l['i'], 'index.php?option=com_phocafont&view=phocafontinfo');
}

if ($view == 'phocafontinfo') {
	JSubMenuHelper::addEntry($l['cp'], 'index.php?option=com_phocafont');
	JSubMenuHelper::addEntry($l['cf'], 'index.php?option=com_phocafont&view=phocafontfonts' );
	JSubMenuHelper::addEntry($l['i'], 'index.php?option=com_phocafont&view=phocafontinfo', true);
}


class PhocaFontCpController extends JController
{
	function display() {
		parent::display();
	}
}
?>
