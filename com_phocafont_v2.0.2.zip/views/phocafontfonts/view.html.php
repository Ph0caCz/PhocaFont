<?php
/*
 * @package		Joomla.Framework
 * @copyright	Copyright (C) 2005 - 2010 Open Source Matters, Inc. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 *
 * @component Phoca Component
 * @copyright Copyright (C) Jan Pavelka www.phoca.cz
 * @license http://www.gnu.org/copyleft/gpl.html GNU General Public License version 2 or later;
 */
defined( '_JEXEC' ) or die();
jimport( 'joomla.application.component.view' );
jimport('joomla.client.helper');
jimport('joomla.filesystem.file');
 
class PhocaFontCpViewPhocaFontFonts extends JView
{

	protected $items;
	protected $pagination;
	protected $state;
	protected $tmpl;
	protected $ftp;


	function display($tpl = null) {
		
		// Check default value
		$model 	= $this->getModel( 'phocafontfonts' );
		$model->checkDefault();
		
		$this->items		= $this->get('Items');
		$this->pagination	= $this->get('Pagination');
		$this->state		= $this->get('State');

		JHTML::stylesheet('administrator/components/com_phocafont/assets/phocafont.css' );
		
		$this->ftp	=& JClientHelper::setCredentialsFromRequest('ftp');
		
		$this->addToolbar();
		parent::display($tpl);
	}
	
	protected function addToolbar() {
		
		require_once JPATH_COMPONENT.DS.'helpers'.DS.'phocafontcp.php';
		
		$state	= $this->get('State');
		$canDo	= PhocaFontHelperControlPanel::getActions();
		
		JToolBarHelper::title( JText::_('COM_PHOCAFONT_FONTS'), 'font.png' );
		
		if ($canDo->get('core.edit.state')) {
			JToolBarHelper::makeDefault('phocafontfont.setDefault', 'COM_PHOCAFONT_MAKE_DEFAULT');
			JToolBarHelper::divider();
		}
		
		if ($canDo->get('core.create')) {
			JToolBarHelper::addNew( 'phocafontfont.add','JTOOLBAR_NEW');
		}
		if ($canDo->get('core.edit')) {
			JToolBarHelper::editList('phocafontfont.edit','JTOOLBAR_EDIT');
		}
		
		
		if ($canDo->get('core.edit.state')) {

			JToolBarHelper::divider();
			JToolBarHelper::custom('phocafontfonts.publish', 'publish.png', 'publish_f2.png','JTOOLBAR_PUBLISH', true);
			JToolBarHelper::custom('phocafontfonts.unpublish', 'unpublish.png', 'unpublish_f2.png', 'JTOOLBAR_UNPUBLISH', true);

		}

		if ($canDo->get('core.delete')) {
			JToolBarHelper::deleteList( JText::_( 'COM_PHOCAFONT_WARNING_DELETE_ITEMS' ), 'phocafontfont.delete', 'COM_PHOCAFONT_DELETE');
		}
		JToolBarHelper::divider();
		JToolBarHelper::help( 'screen.phocafont', true );
	}
}
?>
